archivo = open('campus/mbox-short.txt', 'r')
lineas = archivo.readlines()

mensajes = []
cl = []
# email = set()

for linea in lineas:
    if linea.startswith('From:'):
        mensajes.append(linea.split()[1])
        if mensajes not in cl:
            cl.append(mensajes)

cl.reverse()

archivo_salida = open('campus/mensajes.txt', 'w')

# for mensaje in sorted(mensajes):
#     if mensajes.count(mensaje) > 1:
#         mensajes.remove(mensaje)

for mensaje in cl:
    print(f'{mensaje} enviado [ok]')
    archivo_salida.write(f'{mensaje}\n')

archivo.close()
archivo_salida.close()

