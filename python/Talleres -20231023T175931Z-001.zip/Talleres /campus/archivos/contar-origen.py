def miFun(email):
    return len(email)

fd = open("archivos/mbox-short.txt", "r")

setEmail = set()
cl = 0
# for linea in fd:
#     if linea.startswith("From:"):
#         # cl += 1
#         # email = linea.split()[1]
#         # print(email)
#         setEmail.add(linea.split()[1])

for linea1 in fd:
    if linea1.startswith("To:"):
        setEmail.add(linea1.split()[1])

fd.close()
cl = len(setEmail)
print("Cantidad de correso distintos: ", cl)

# for email in sorted(setEmail, reverse = False, key=miFun):
#     print(email)

for email1 in sorted(setEmail, reverse = False, key=miFun):
    print(f"{email1} enviado [ok]")