mde = open("archivos/datosEmpleados.dat", "r")


# mde.seek(0)
# texto2 = mde.readline()
# print(texto2)

# texto = mde.read()
# texto2 = texto.split("\n")

# for fila in mde:
#     texto3 = texto2[fila].split(",")
#     # print(texto3)
#     for columna in range(7):
#         # texto.split()[0]
#         print(texto3[0][fila])

for linea in mde:
    if not linea.startswith("ID"):
        datos = linea.split(",")
        print(f"ID: {datos[0]}\nNOMBRE: {datos[1]}\nEDAD: {datos[2]}\nSEXO: {datos[3]}\nTELEFONO: {datos[4]}")
        print("-"*30)



mde.close()




# fd.close()
# cl = len(setEmail)
# print("Cantidad de correso distintos: ", cl)

# # for email in sorted(setEmail, reverse = False, key=miFun):
# #     print(email)

# for email1 in sorted(setEmail, reverse = False, key=miFun):
#     print(f"{email1} enviado [ok]")