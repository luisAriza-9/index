import json

def guardarLibro(lstJugador, ruta):
    try:
        clasificacion = open(ruta, "w")
    except Exception as e:
        print("Error al abrir el archivo para guardar datos del jugador.\n", e)
        return None
    
    try:
        json.dump(lstJugador, clasificacion)
    except Exception as e:
        print("Error al guardar la información del jugador.\n", e)
        return None
    
    clasificacion.close()
    return True

# Aquí el código inserta el registro en el archivo y lo mantiene ordenado

def leerNombre():
    while True:
        try:
            nombre = input("Ingrese el nombre del jugador: ")
            nombre = nombre.strip()
            if len(nombre) == 0 or nombre.isalnum() == False:
                print("Nombre inválido. Vuelva a digitarlo.")
                continue
            break
        except Exception as e:
            print("Error al ingresar el nombre.\n", e)

def insertar_registro(lstJugador, ruta):
    print("\n\n1. Jugar Partida")
    
    # id = input("Ingrese el código del libro: ")
    # while existeId(id, lstLibro):
    #     print("--> Ya existe un empleado con ese ID")
    #     input()
    #     id = input("\nIngrese el código del libro: ")

    print("Datos del juagdor 1")
    nombre = leerNombre()
    print("Datos del jugador 2")
    nombre2 = leerNombre()
    ficha = input("Ingrese ficha de jugador 1: (X - O) ")

    dicLibro = {}
    dicLibro = {"nombre":nombre, "ficha":ficha}
    lstJugador.append(dicLibro)

    for i in range(len(lstJugador) - 1):
        for j in range(len(lstJugador) - 1 - i):
            if lstJugador[j]['nombre'] > lstJugador[j + 1]['nombre']:
                lstJugador[j], lstJugador[j + 1] = lstJugador[j + 1], lstJugador[j]
    
    if guardarLibro(lstJugador, ruta) == True:
        input("El libro ha sido registrado con éxito.\nPresione cualquier tecla para continuar...")
    else:
        input("Ocurrio algún error al guardar el libro.")


#Funcion Menu
def menu():
    while True:
        try:
            print("\n" * 30)
            print("*** TIC TAC TOE***".center(40))
            print("MENU".center(40))
            print("1. Jugar Partida")
            print("2. Tabla de Clasificación")
            print("3. Salir")

            op = int(input(">>> Opción (1-3)? "))
            if op < 1 or op > 3:
                print("Opción no válida. Escoja de 1 a 3.")
                input("Presione cualquier tecla para continuar...")
                continue
            return op
        except ValueError:
            print("Opción no válida. Escoja de 1 a 3.")
            input("Presione cualquier tecla para continuar...")