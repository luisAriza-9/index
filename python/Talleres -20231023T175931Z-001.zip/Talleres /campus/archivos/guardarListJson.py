import json

fd = open("campus/archivos/lista.json", "w")

lst = [{"nombre":"Paola", "edad":25},
       {"nombre":"Carlos", "edad":28},
       {"nombre":"Juan", "edad":18},
       {"nombre":"Mateo", "edad":19},
       {"nombre":"Patricia", "edad":21}]

json.dump(lst, fd)

fd.close()