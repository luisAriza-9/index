fd = open("archivos/mbox-short.txt", "r")

cl = 0
cp = 0
for linea in fd:
    linea = linea.strip()
    linea.split(" ")
    cp += len(linea.split(" "))
    cl += 1

fd.close()

print("Cantidad de lineas: ", cl)
print(f"Cantidad de palabras: ", cp)