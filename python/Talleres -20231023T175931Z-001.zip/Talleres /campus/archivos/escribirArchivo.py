archivo = open("archivos/salas.txt", "w")

archivo.write("sputnik\n\t")
archivo.write("apolo\n")

archivo.writelines(["houston\n", "Artemis\n"])

archivo.close()