import json

def guardarJuego(lstJugador, ruta):
    try:
        clasificacion = open(ruta, "w")
    except Exception as e:
        print("Error al abrir el archivo para guardar datos del jugador.\n", e)
        return None
    
    try:
        json.dump(lstJugador, clasificacion)
    except Exception as e:
        print("Error al guardar la información del jugador.\n", e)
        return None
    
    clasificacion.close()
    return True

def leerNombre():
    while True:
        try:
            nombre = input("Ingrese el nombre del jugador: ")
            nombre = nombre.strip()
            if len(nombre) == 0 or nombre.isalnum() == False:
                print("Nombre inválido. Vuelva a digitarlo.")
                continue
            break
        except Exception as e:
            print("Error al ingresar el nombre.\n", e)
    return nombre

# while True:
#     try:
#         nombre = input("Ingrese el nombre del jugador 1: ")
#         nombre = nombre.strip()
#         if len(nombre) == 0 or nombre.isalnum() == False:
#             print("Nombre inválido. Vuelva a digitarlo.")
#             continue
#         break
#     except Exception as e:
#         print("Error al ingresar el nombre.\n", e)

def leerFicha():
    while True:
        try:
            ficha = input("Ingrese ficha del jugador 1: (X - O) ")
            ficha = ficha.strip()
            ficha = ficha.upper()
            if len(ficha) == 0 or ficha != "O" and ficha != "X":
                print("Ficha inválida. Vuelva a digitarlo.")
                continue
            break
        except Exception as e:
            print("Error al ingresar la ficha.\n", e)

def leerRespuesta():
    while True:
        try:
            respuesta = int(input("Ingresa un número entero entre 1 - 9: "))
            if respuesta < 1 or respuesta > 9:
                print("El número está fuera del rango (1-9). Intente de nuevo")
                continue
            break
        except ValueError:
            print("Error. número inválido.")
    return respuesta

# while True:
#     try:
#         nombre2 = input("Ingrese el nombre del jugador 2: ")
#         nombre2 = nombre2.strip()
#         if len(nombre2) == 0 or nombre2.isalnum() == False:
#             print("Nombre inválido. Vuelva a digitarlo.")
#             continue
#         break
#     except Exception as e:
#         print("Error al ingresar el nombre.\n", e)

# print(ficha)
def jugarPartida():
    #Lo que se intenta es agregar a los jugadores en una lista
    nombre1 = leerNombre()
    ficha = leerFicha()
    print(ficha)
    nombre2 = leerNombre()
    jugador = []
    jugador = [nombre1, nombre2]
    jugadores = []
    jugadores.append(jugador)

    fichero = []

    if ficha == "X":
        ficJug1 = "X"
        ficJug2 = "O"
    else:
        ficJug1 = "O"
        ficJug2 = "X"
    fichero = [ficJug1, ficJug2]

    tablero = [[1, 2, 3],
                [4, 5 ,6],
                [7, 8, 9]]
    
    while True:
        # nuevoTablero = []
        for i in range(len(jugador)):
            print(f"El jugador {jugador[i]} usa la ficha {fichero[i]}")
            print(tablero[0])
            print(tablero[1])
            print(tablero[2])
            
            respuesta = leerRespuesta()
            # def verificarOcupados():
            #     for element in tablero:
            #             if element:
            #                 return True
            #         return False
            # if resp
            fich1 = []
            fich2 = []
            movimientos = [fich1, fich2]
            for fila in range(len(tablero)):
                for columna in range(len(tablero[0])):
                
                    if tablero[fila][columna] == respuesta:
                        tablero[fila][columna] = fichero[i]
                    elif respuesta not in tablero:
                        print(f"La casilla {respuesta} esta ocupada")
                        input()
                        continue
                        # movimientos[i] += 1
                        # nuevoTablero.append(tablero)
                        # print(nuevoTablero)
                    # if tablero[0][0] == fichero[i] and tablero[1][1] == fichero[i] and tablero[2][2] == fichero[i]:
                    #     print(f"El jugador {jugador[i]} es el ganador")

            if tablero[0][0] == fichero[i] and tablero[1][1] == fichero[i] and tablero[2][2] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(f"Cantidad de movimientos: {movimientos[i]}")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[0][0] == fichero[i] and tablero[1][0] == fichero[i] and tablero[2][0] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[0][0] == fichero[i] and tablero[0][1] == fichero[i] and tablero[0][2] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[0][1] == fichero[i] and tablero[1][1] == fichero[i] and tablero[2][1] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[0][2] == fichero[i] and tablero[1][1] == fichero[i] and tablero[2][0] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[0][2] == fichero[i] and tablero[1][2] == fichero[i] and tablero[2][2] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[1][0] == fichero[i] and tablero[1][1] == fichero[i] and tablero[1][2] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            elif tablero[2][0] == fichero[i] and tablero[2][1] == fichero[i] and tablero[2][2] == fichero[i]:
                print(f"El jugador {jugador[i]} es el ganador")
                print(tablero[0]),print(tablero[1]),print(tablero[2])
                return False
            # elif tablero[]

def menu():
    while True:
        try:
            print("--- TIC TAC TOE ---")
            print("------ MENÚ ------")
            print("1. Jugar Partida")
            print("2. Tabla de clasificación")
            print("3. Salir")


            opcion = int(input("Seleccione una opción: "))
            if opcion < 1 or opcion > 3:
                print("Opción no válida. Escoja de 1 a 3.")
                input("Presione cualquier tecla para continuar...")
                continue
            return opcion
        except ValueError:
            print("Opción no válida. Escoja de 1 a 3.")
            input("Presione cualquier tecla para continuar...")




while True:
    opcion = menu()

    if opcion == 1:
        jugarPartida()
    elif opcion == 2:
        pass
    elif opcion == 3:
        print("Hasta Luego!")
        break
    else:
        print("Opción inválida. Por favor, seleccione una opción válida.")
        input("Presione cualquier tecla para continuar...")
        continue
