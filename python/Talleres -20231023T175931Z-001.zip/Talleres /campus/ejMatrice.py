matriz_a = [[1, 2, 3],
            [4, 5 ,6],
            [7, 8, 9]]

matriz_b = [[1, 2, 3],
            [4, 5 ,6],
            [7, 8, 9]]

matriz_c = []

for row in range(len(matriz_a)):
    newRows = []
    for columns in range(len(matriz_a[0])):
        newRows.append(matriz_a[row][columns] + matriz_b[row][columns])
    matriz_c.append(newRows)

for pr in range(len(matriz_a)):
    print(f"{matriz_a[pr]} + {matriz_b[pr]} = {matriz_c[pr]}")


#Ejercicio 2 de suma de matrices
numMatriz = int(input("Digite la cantidad de matrices que desea sumar: "))

if numMatriz > 1:
    row = int(input("Digite la cantidad de filas que tendrá la matriz: "))
    columns = int(input("Digite la cantidad de columnas que tendrá la matriz: "))
    listMatriz = []
    for num in range(numMatriz):
        matriz = []
        for nRow in range(row):
            numRows = []
            for nColumns in range(columns):
                numRows.append(f"Digite un núemro para la matriz {numMatriz}, fila {nRow}, columna {nColumns}: ")
            matriz.append(numRows)
        listMatriz.append(matriz)

    matriz = []
    for nRow in range(row):
        numRows = []
        for nColumns in range(columns):
            sumMatriz = 0
            for matPosition in range(listMatriz):
                sumMatriz += listMatriz[matPosition][nRow][nColumns]
            numRows.append(sumMatriz)
        matriz.append(numRows)
    listMatriz.append(matriz) 
        

else:
    print("Se requiere más de 2 matrices para realizar la operación: ")


