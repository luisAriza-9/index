# def es_entero(numero):
#     return isinstance(numero, int)

def generar_primos(n, m):
    primos = []
    for num in range(n, m):
        if num > 1:
            for i in range(2, num):
                if (num % i) == 0:
                    break
            else:
                primos.append(num)
    return primos

def mostrar_primos():
    rango_inicial = int(input("Rango inicial: "))
    rango_final = int(input("Rango final: "))

    primos = generar_primos(rango_inicial, rango_final)

    print(f"Los números primos entre [{rango_inicial} y {rango_final}] son: {'|'.join(map(str, primos))}")
    print(f"Cantidad de números primos: {len(primos)}")

# Ejemplo de uso del programa
mostrar_primos()