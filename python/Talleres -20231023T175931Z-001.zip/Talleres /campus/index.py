def calcular_serie(n):
    if n < 1:
        return 0

    serie = []
    resultado = 0

    for i in range(1, n+1):
        termino = (-1) ** (i+1) * (1/i)
        resultado += termino
        serie.append(termino)

    cantidad_terminos = len(serie)

    return cantidad_terminos, resultado


# Ejemplo de uso de la función
numero = int(input("Ingrese un número entero: "))
cantidad_terminos = calcular_serie(numero) 
resultado = calcular_serie(numero)
print(f"Cantidad de términos: {cantidad_terminos}")
print(f"Resultado de la serie: {resultado}")