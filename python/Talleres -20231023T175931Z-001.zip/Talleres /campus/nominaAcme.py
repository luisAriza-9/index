# Definir una lista vacía para almacenar los empleados
empleados = []

# Función para agregar un empleado
def agregar_empleado():
    id_empleado = input("Ingrese el ID del empleado: ")
    nombre = input("Ingrese el nombre del empleado: ")
    horas_trabajadas = int(input("Ingrese las horas trabajadas: "))
    valor_hora = float(input("Ingrese el valor de la hora: "))

    # Validar las horas trabajadas y el valor de la hora
    if horas_trabajadas < 1 or horas_trabajadas > 160:
        print("Error: Las horas trabajadas deben estar entre 1 y 160.")
        return
    if valor_hora < 8000 or valor_hora > 150000:
        print("Error: El valor de la hora debe estar entre $8,000 y $150,000 pesos.")
        return

    # Crear un diccionario con la información del empleado
    empleado = {
        "id": id_empleado,
        "nombre": nombre,
        "horas_trabajadas": horas_trabajadas,
        "valor_hora": valor_hora
    }

    # Agregar el empleado a la lista
    empleados.append(empleado)
    print("Empleado agregado exitosamente.")

# Función para modificar un empleado
def modificar_empleado():
    id_empleado = input("Ingrese el ID del empleado que desea modificar: ")

    # Buscar el empleado por su ID
    for empleado in empleados:
        if empleado["id"] == id_empleado:
            nombre = input("Ingrese el nuevo nombre del empleado: ")
            horas_trabajadas = int(input("Ingrese las nuevas horas trabajadas: "))
            valor_hora = float(input("Ingrese el nuevo valor de la hora: "))

            # Validar las horas trabajadas y el valor de la hora
            if horas_trabajadas < 1 or horas_trabajadas > 160:
                print("Error: Las horas trabajadas deben estar entre 1 y 160.")
                return
            if valor_hora < 8000 or valor_hora > 150000:
                print("Error: El valor de la hora debe estar entre $8,000 y $150,000 pesos.")
                return

            # Actualizar los datos del empleado
            empleado["nombre"] = nombre
            empleado["horas_trabajadas"] = horas_trabajadas
            empleado["valor_hora"] = valor_hora

            print("Empleado modificado exitosamente.")
            return

    print("No se encontró ningún empleado con ese ID.")

# Función para buscar un empleado
def buscar_empleado():
    id_empleado = input("Ingrese el ID del empleado que desea buscar: ")

    # Buscar el empleado por su ID
    for empleado in empleados:
        if empleado["id"] == id_empleado:
            print("Información del empleado:")
            print("ID:", empleado["id"])
            print("Nombre:", empleado["nombre"])
            print("Horas trabajadas:", empleado["horas_trabajadas"])
            print("Valor de la hora:", empleado["valor_hora"])
            return

    print("No se encontró ningún empleado con ese ID.")

# Función para eliminar un empleado
def eliminar_empleado():
    id_empleado = input("Ingrese el ID del empleado que desea eliminar: ")

    # Buscar el empleado por su ID
    for empleado in empleados:
        if empleado["id"] == id_empleado:
            empleados.remove(empleado)
            print("Empleado eliminado exitosamente.")
            return

    print("No se encontró ningún empleado con ese ID.")

# Función para listar los empleados
def listar_empleados():
    # pagina = 1
    # empleados_por_pagina = 5

    while True:
        # inicio = (pagina - 1) * empleados_por_pagina
        # fin = inicio + empleados_por_pagina

        # Mostrar los empleados de la página actual
        print("Empleados:")
        # for empleado in empleados[inicio:fin]:
        for empleado in empleados:

            print("ID:", empleado["id"])
            print("Nombre:", empleado["nombre"])
            print("Horas trabajadas:", empleado["horas_trabajadas"])
            print("Valor de la hora:", empleado["valor_hora"])
            print("--------------------")

        # Verificar si hay más empleados para mostrar
        # if fin >= len(empleados):
        #     print("No hay más empleados.")
        #     break

        # Preguntar al usuario si desea ver más empleados
        # respuesta = input("¿Desea ver más empleados? (s/n): ")
        # if respuesta.lower() != "s":
        #     break

        # pagina += 1

# Función para listar la nómina de un empleado
def listar_nomina_empleado():
    id_empleado = input("Ingrese el ID del empleado: ")

    # Buscar el empleado por su ID
    for empleado in empleados:
        if empleado["id"] == id_empleado:
            salario_bruto = empleado["horas_trabajadas"] * empleado["valor_hora"]
            salario_minimo = 908526  # Salario mínimo legal vigente en Colombia 2023
            subsidio_transporte = 106454  # Valor del subsidio de transporte en Colombia 2023
            descuento_eps = salario_bruto * 0.04
            descuento_pension = salario_bruto * 0.04
            salario_neto = salario_bruto + subsidio_transporte - descuento_eps - descuento_pension

            print("Nómina del empleado:")
            print("ID:", empleado["id"])
            print("Nombre:", empleado["nombre"])
            print("Salario bruto:", salario_bruto)
            print("Descuento EPS:", descuento_eps)
            print("Descuento Pensión:", descuento_pension)
            print("Salario neto:", salario_neto)
            return

    print("No se encontró ningún empleado con ese ID.")

# Función para listar la nómina de todos los empleados
def listar_nomina_todos_empleados():
    for empleado in empleados:
        salario_bruto = empleado["horas_trabajadas"] * empleado["valor_hora"]
        salario_minimo = 908526  # Salario mínimo legal vigente en Colombia 2023
        subsidio_transporte = 106454  # Valor del subsidio de transporte en Colombia 2023
        descuento_eps = salario_bruto * 0.04
        descuento_pension = salario_bruto * 0.04
        salario_neto = salario_bruto + subsidio_transporte - descuento_eps - descuento_pension

        print("Nómina del empleado:")
        print("ID:", empleado["id"])
        print("Nombre:", empleado["nombre"])
        print("Salario bruto:", salario_bruto)
        print("Descuento EPS:", descuento_eps)
        print("Descuento Pensión:", descuento_pension)
        print("Salario neto:", salario_neto)
        print("--------------------")

# Función para mostrar el menú y procesar la opción seleccionada
def mostrar_menu():
    while True:
        print("*** NOMINA ACME ***")
        print("MENU")
        print("1- Agregar empleado")
        print("2- Modificar empleado")
        print("3- Buscar empleado")
        print("4- Eliminar empleado")
        print("5- Listar empleados")
        print("6- Listar nómina de un empleado")
        print("7- Listar nómina de todos los empleados")
        print("8- Salir")

        opcion = input("Escoja una opción (1-8): ")

        if opcion == "1":
            agregar_empleado()
        elif opcion == "2":
            modificar_empleado()
        elif opcion == "3":
            buscar_empleado()
        elif opcion == "4":
            eliminar_empleado()
        elif opcion == "5":
            listar_empleados()
        elif opcion == "6":
            listar_nomina_empleado()
        elif opcion == "7":
            listar_nomina_todos_empleados()
        elif opcion == "8":
            confirmacion = input("¿Está seguro de que desea salir? (s/n): ")
            if confirmacion.lower() == "s":
                print("¡Hasta luego!")
                break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")

# Ejecutar el programa
mostrar_menu()
