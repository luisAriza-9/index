import json

def guardarLibro(lstLibro, ruta):
    try:
        fichero = open(ruta, "w")
    except Exception as e:
        print("Error al abrir el archivo para guardar el libro.\n", e)
        return None
    
    try:
        json.dump(lstLibro, fichero)
    except Exception as e:
        print("Error al guardar la información del libro.\n", e)
        return None
    
    fichero.close()
    return True

def existeId(id, lstLibro):
    for datos in lstLibro:
        k = list(datos.keys())[0]
        if k == id:
            return True
    return False

    
    # for libro in range(len(lstLibro)):
    #     if libro["id"] == codigo:
            
    #         del lstLibro[libro]
    #         break
        
    #     if guardarLibro(lstLibro, rutaFile) == True:
    #         print("El libro ha sido borrado con exito")
    #         input()
    #     else:
    #         print("Ocurrio un error al borrar el libro")



# Aquí el código inserta el registro en el archivo y lo mantiene ordenado
def insertar_registro(lstLibro, ruta):
    print("\n\n1. Agregar Libro")
    
    id = input("Ingrese el código del libro: ")
    while existeId(id, lstLibro):
        print("--> Ya existe un empleado con ese ID")
        input()
        id = input("\nIngrese el código del libro: ")

    titulo = input("Ingrese el título del libro: ")
    autor = input("Ingrese el autor del libro: ")
    precio = float(input("Ingrese el precio del libro: "))

    dicLibro = {}
    dicLibro = {"id": id, "titulo":titulo, "autor":autor, "precio":precio}
    lstLibro.append(dicLibro)

    for i in range(len(lstLibro) - 1):
        for j in range(len(lstLibro) - 1 - i):
            if lstLibro[j]['id'] > lstLibro[j + 1]['id']:
                lstLibro[j], lstLibro[j + 1] = lstLibro[j + 1], lstLibro[j]
    
    if guardarLibro(lstLibro, ruta) == True:
        input("El libro ha sido registrado con éxito.\nPresione cualquier tecla para continuar...")
    else:
        input("Ocurrio algún error al guardar el libro.")


def borrarLibro(lstLibro):
    print("\n\n4. Borrar Libro")
    
    codigo = input("Ingrese el codigo del libro que desea eliminar: ")

    for libro in lstLibro:
        if libro["id"] == codigo:
            lstLibro.remove(libro)
            guardarLibro(lstLibro, rutaFile)
            print("Libro eliminado exitosamente.")
            input()
            return

    print("No se encontró ningún libro con ese codigo.")
    print()

def editar_libro(lstLibro):
    print("\n\n3. Editar Libro")
    id_empleado = input("Ingrese el codigo del libro que desea modificar: ")

    for libro in lstLibro:
        if libro["id"] == id_empleado:
            titulo = input("Ingrese el título del libro: ")
            autor = input("Ingrese el autor del libro: ")
            precio = float(input("Ingrese el precio del libro: "))

            libro["titulo"] = titulo
            libro["autor"] = autor
            libro["precio"] = precio

            guardarLibro(lstLibro, rutaFile)
            
            print("Datos de Libro modificado exitosamente.")
            return

    print("No se encontró ningún libro con ese codigo.")

# Aquí el código busca el registro en el archivo por el campo código
def consultar_registro(lstLibro):
    print("\n\n2. Consultar Libro")
    codigo = input("Ingrese el código del libro a buscar: ")

    for libro in lstLibro:
        # print(lstLibro)
        if libro["id"] == codigo:
            print("Libro consultado: ")
            print(f"Código: {libro['id']}")
            print(f"Titulo: {libro['titulo']}")
            print(f"Autor: {libro['autor']}")
            print(f"Precio: {libro['precio']}")
            input()

def listarPorNombre(lstLibro):
    print("\n\n5. Listar Libro por Título")
    nombre = input("Ingrese el titulo del libro a buscar: ")

    for libro in lstLibro:
        # print(lstLibro)
        if libro["titulo"] == nombre:
            print("Libro consultado: ")
            print(f"Código: {libro['id']}")
            print(f"Titulo: {libro['titulo']}")
            print(f"Autor: {libro['autor']}")
            print(f"Precio: {libro['precio']}")
            input()

def listarPorAutor(lstLibro):
    print("\n\n6. Listar Libro por Autor")
    autor = input("Ingrese el autor del libro a buscar: ")

    for libro in lstLibro:
        if libro["autor"] == autor:
            print("Libro consultado: ")
            print(f"Código: {libro['id']}")
            print(f"Titulo: {libro['titulo']}")
            print(f"Autor: {libro['autor']}")
            print(f"Precio: {libro['precio']}")
            input()

def listarPorPrecio(lstLibro):
    print("\n\n7. Listar Libro por Precio")
    precio = input("Ingrese el precio del libro a buscar: ")

    for libro in lstLibro:
        if libro["precio"] == precio:
            print("Libro consultado: ")
            print(f"Código: {libro['id']}")
            print(f"Titulo: {libro['titulo']}")
            print(f"Autor: {libro['autor']}")
            print(f"Precio: {libro['precio']}")
            input()

def menu():
    while True:
        try:
            print("----- MENÚ -----")
            print("1. Insertar registro")
            print("2. Consultar registro")
            print("3. Editar")
            print("4. Eliminar")
            print("5. Listar por título")
            print("5. Lidtar por autor")
            print("7. Listar por precio")
            print("8. Salir")


            opcion = int(input("Seleccione una opción: "))
            if opcion < 1 or opcion > 8:
                print("Opción no válida. Escoja de 1 a 8.")
                input("Presione cualquier tecla para continuar...")
                continue
            return opcion
        except ValueError:
            print("Opción no válida. Escoja de 1 a 8.")
            input("Presione cualquier tecla para continuar...")


def cargarInfo(lstLibro, ruta):
    try:
        fichero = open(ruta, "r")
    except Exception as e:
        try:
            fichero = open(ruta, "w")
        except Exception as d:
            print("Error al intentar abrir el archivo\n", d)
            return None
    try:
        linea = fichero.readline()
        if linea.strip() != "":
            fichero.seek(0)
            lstLibro = json.load(fichero)
        else:
            lstLibro = []
    except Exception as e:
        print("Error al cargar la información\n", e)
        return None
    
    print(lstLibro)
    fichero.close()
    return lstLibro

rutaFile = "campus/datLibro.json"
lstLibro = []
lstLibro =cargarInfo(lstLibro, rutaFile)

while True:
    opcion = menu()

    if opcion == 1:
        insertar_registro(lstLibro, rutaFile)
    elif opcion == 2:
        consultar_registro(lstLibro)
    elif opcion == 3:
        editar_libro(lstLibro)
    elif opcion == 4:
        borrarLibro(lstLibro)
    elif opcion == 5:
        listarPorNombre(lstLibro)
    elif opcion == 6:
        listarPorAutor(lstLibro)
    elif opcion == 7:
        listarPorPrecio(lstLibro)
    elif opcion == 8:
        print("Hasta Luego!")
        break
    else:
        print("Opción inválida. Por favor, seleccione una opción válida.")
        input("Presione cualquier tecla para continuar...")
        continue
