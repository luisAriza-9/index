str1 = "Abrilz"
str2 = "Abrilamico"

#Condicional simple
# if str1 < str2:
#     print("La cadena 1 es menos a la cadena 2")

# print("Fin del codigo")

#Condicional doble
