print("Hola mundo :D")
