base = float(input("Ingrese la base del triangulo: "))
altura = float(input("Ingrese la altura del triangulo: "))
area = (base * altura) /2
print(f"El area del triangulo es: {area:.2f}")
