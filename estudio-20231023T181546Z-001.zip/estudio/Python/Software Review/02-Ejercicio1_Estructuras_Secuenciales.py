sName = "Alejandro Palacio"
fReto1 = 3.2
fReto2 = 3.6
fReto3 = 4.0
fIngles = 2.8 

fDefinitiva = (fReto1 * 0.2) + (fReto2 * 0.25) + (fReto3 * 0.35) + (fIngles * 0.2)

print(f"La calificacion definitiva de {sName} es: {fDefinitiva:,.2f}")