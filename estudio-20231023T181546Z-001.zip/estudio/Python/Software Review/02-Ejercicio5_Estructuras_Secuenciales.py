fNota = float(input("Ingrese el valor de la nota: "))

fcurva = fNota * 0.8 + 1

print(f"Aplicando la curva, la nueva note es de: {fcurva}")